@extends('frontend/master')
@section('content')

<div class="body contact-page">
        <!--section 1-->
        <section>
            <div class="contact-page-banner">
                <h1>Thank You</h1>
                         
            </div>
        </section>
     
        <section>
            
        </section>
        <!--section 3-->
        <!--section 4-->
        <section>
            
        </section>
        
        <!--section 4-->        
    </div>

@endsection