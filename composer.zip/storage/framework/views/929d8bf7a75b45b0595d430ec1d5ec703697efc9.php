<div class="homepage-section4 get-best-energy-rate-div">
    <div class="bg-get-best-energy-rate-div">
        <img src="content/images/homepage-bg-section4.jpg" class="hidden-sm hidden-xs" />
    </div>
    <div class="get-best-energy-rate-div-inner">
        <div class="get-best-energy-rate-div-txt wow zoomIn" data-wow-delay="0.2s">
            <h2>get the best<br />energy rates in<br />your area</h2>
            <p>
                Use our advanced AI price tool to get
                the best possible rate estimate quotation
                for your area. No obligations.
            </p>
            <a class="get-best-energy-rate-div-btn">Coming Soon!</a>
        </div>
        <div class="get-best-energy-rate-div-poweredby">Powered by <span><img src="content/images/p-icon.png" /> Intelligence</span></div>
    </div>
</div>