<?php $__env->startSection('content'); ?>

<div class="body about-page">
        <!--section 1-->
        <section>
            <div class="commercial-section1">
                <div class="wow fadeInUp" data-wow-delay="0.4s">
                    <h2>Commercial energy consulting<br />we’re the specialists!</h2>
                    <p>Park Place Power LLC. is a Multi-Certified Commercial Energy Brokerage & Consulting Firm that values our clients and relationships.  As we negotiate electricity rates and contract language on your behalf, you will quickly realize that we work for you and not the energy suppliers, which means your needs come first!</p>
                    <div class="button-div">
                        <a class="button-explore" data-toggle="modal" data-target="#myModalQuote">get your quote&nbsp; ></a>
                        <a href='<?php echo e(asset('contact-us')); ?>' class="btn-get-in-touch">get in touch with us</a>
                    </div>
                </div>
                <!--<a class="scroll-down"><img src="<?php echo e(asset('content/images/scroll-down-arrows.png')); ?>" /> scroll down</a>-->
            </div>
        </section>
        <!--section 1-->
        <!--section 2-->
        <section>
            <div class="about-section2">
                <div class="about-section2-part1 wow fadeInUp">
                    <div class="about_slider">
                        <div class="items">
                            <div class="about-section2-blk">
                                <div class="about-section2-txt-blk1">
                                    <h4>Honesty</h4>
                                    <span></span>
                                    <p>We believe in direct, open and honest communication</p>
                                </div>
                                <img src="<?php echo e(asset('content/images/about-us/honesty.jpg')); ?>" />
                            </div>
                        </div>
                        <div class="items">
                            <div class="about-section2-blk">
                                <div class="about-section2-txt-blk1">
                                    <h4>Transparency</h4>
                                    <span></span>
                                    <p>Your needs comes first</p>
                                </div>
                                <img src="<?php echo e(asset('content/images/about-us/transparency.jpg')); ?>" />
                            </div>
                        </div>
                        <div class="items">
                            <div class="about-section2-blk">
                                <div class="about-section2-txt-blk1">
                                    <h4>Integrity</h4>
                                    <span></span>
                                    <p>We work for you and not for our energy suppliers</p>
                                </div>
                                <img src="<?php echo e(asset('content/images/about-us/integrity.jpg')); ?>" />
                            </div>
                        </div>
                        <div class="items">
                            <div class="about-section2-blk">
                                <div class="about-section2-txt-blk1">
                                    <h4>Accountability</h4>
                                    <span></span>
                                    <p>We have an unwavering commitment in providing you the best 5 Star service.</p>
                                </div>
                                <img src="<?php echo e(asset('content/images/about-us/accountability.jpg')); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-section2-part2 wow fadeInUp" data-wow-delay="0.4s">
                    <h4>WELCOME</h4>
                    <h2>We are committed to serving your needs</h2>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <div class="about-section2-blk2">
                                <div class="about-section2-img">
                                    <img src="<?php echo e(asset('content/images/about-us/energy.png')); ?>" />
                                </div>
                                <div class="about-section2-txt-blk2">
                                    <h3>Personalised service</h3>
                                    <p>Here at Park Power Place, we customize our approach and plans to suit the needs of each and every individual.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <div class="about-section2-blk2">
                                <div class="about-section2-img">
                                    <img src="<?php echo e(asset('content/images/about-us/accounting.png')); ?>" />
                                </div>
                                <div class="about-section2-txt-blk2">
                                    <h3>Continuous Market Watch</h3>
                                    <p>We identify and eliminate issues before they can take effect and update you on any changes in the market. </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <div class="about-section2-blk2">
                                <div class="about-section2-img">
                                    <img src="<?php echo e(asset('content/images/about-us/network.png')); ?>" />
                                </div>
                                <div class="about-section2-txt-blk2">
                                    <h3>Client Reputation</h3>
                                    <p>5 Star Service is Standard </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--section 2-->
        <!--section 3-->
        <section>
            <div class="about-section3">
                <div class="row d-flex">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="about-section3-txt wow fadeInUp">
                            <h4>Our Story</h4>
                            <h2>A plan for future</h2>
                            <div class="about-section3-img wow zoomIn">

                            </div>
                            <p>We are the power industry’s leading company and we’ve grown from a power generator into an energy provider that powers homes and businesses throughout America.</p>
                            <p>Our customer-focused mentality has led us to create technologies and tools that empower residents and organisations to think critically about their electricity, including where their power is coming from, what impact it has on the environment and how they can become more conscious energy users.  We partner with businesses to customise innovative power and sustainability solutions that are informed by our years of experience as market leaders. And we work diligently to stay ahead of an ever-evolving energy climate with rising demands.</p>
                            <p>Energy is all around us, fuelling our day-to-day experiences. It keeps our families safe, it keeps our businesses running and it helps our neighbourhoods thrive. But we have to be willing to transform the way we approach energy and imagine new solutions that will strengthen our collective energy community. We’re proud to be leading that transformation, and we hope you’ll join us. </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 hidden-sm hidden-xs pad-zero">
                        <div class="about-section3-img wow zoomIn">

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--section 3-->
        <!--section 4-->
        <section>
            <div class="about-section4">
                <h2>Our integrated platform</h2>
                <h4>We can service business of any size. The only factor is your energy requirements and consumption.</h4>
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="about-section4-blk wow fadeInUp">
                            <div class="about-section4-img">
                                <img src="<?php echo e(asset('content/images/about-us/home.png')); ?>" />
                            </div>
                            <div class="about-section4-txt-blk">
                                <h3>Residential</h3>
                                <p>Our goal is to make sure that our residential customers can sleep at night knowing they have secured their residential contract with a reputable supplier that will not take advantage of them.
 </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="about-section4-blk wow fadeInUp">
                            <div class="about-section4-img">
                                <img src="<?php echo e(asset('content/images/about-us/brokerage.png')); ?>" />
                            </div>
                            <div class="about-section4-txt-blk">
                                <h3>Business</h3>
                                <p>We identify which suppliers and programs would best fit your energy needs and adjust to any future or sudden unexpected changes within your organization’s operation platform.
 </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="about-section4-blk wow fadeInUp">
                            <div class="about-section4-img">
                                <img src="<?php echo e(asset('content/images/about-us/charging.png')); ?>" />
                            </div>
                            <div class="about-section4-txt-blk">
                                <h3>Prepaid/Postpaid</h3>
                                <p>As your energy specialist, we are flexible to any plans you are comfortable with. All you need to do is to tell us your preference. 
 </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="commercial-section4">
                <div class="commercial-section4-container">
                    <div class="row d-flex wow fadeInUp">
                        <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12 pad-zero">
                            <h4>partnerships</h4>
                            <h2>We have over <span>25+</span> suppliers and we select<br />the best for you</h2>
                            <p class="hidden-xs">We at Park Power Place only work with our trusted suppliers who share the same values to build a stable network of unwavering commitment to you our clients.</p>
                        </div>
                        <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12 pad-zero text-right">
                            <img src="<?php echo e(asset('content/images/commercial-energy/partnership-pattern.png')); ?>" class="patrnrship-pattern" />
                            <p class="visible-xs">We at Park Power Place only work with our trusted suppliers who share the same values to build a stable network of unwavering commitment to you our clients.</p>
                        </div>
                    </div>
                    <h3>Scroll to see the entire list <img src="<?php echo e(asset('content/images/arrow-pointing-to-right-blue.png')); ?>" /></h3>                    
                </div>                
            </div>
            <div class="about-logo-slider-div">
                <div class="commercial-section4-container">
                    <div class="slider-our-suppliers wow fadeInUp">
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/reliant-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/mid-american-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/cirro-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/direct-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/fulcrom-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/hudson-logo.jpg')); ?>" />
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('content/images/reliant-logo.jpg')); ?>" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="values-div">
                <div class="value-container wow fadeInUp">
                    <div class="row values-div1">
                        <div class="col-lg-5 col-md-4 col-sm-4 hidden-xs val-p-icon">
                            <img src="<?php echo e(asset('content/images/about-us/p-icon.png')); ?>" />
                        </div>
                        <div class="col-lg-7 col-md-8 col-sm-8 col-xs-12 value-div-txt">
                            <h3>Values we stand for</h3>
                            <h4>Our purpose and values</h4>
                            <p>
                                We bring the power of energy to people and organizations.
                                We are an energy company powered by people and built on dynamic retail brands with diverse generation resources.
                            </p>
                            <img src="<?php echo e(asset('content/images/about-us/p-icon.png')); ?>" class="visible-xs val-p-img"/>
                        </div>
                    </div>
                    <div class="row values-div2">
                        <div class="val-blk">
                            <img src="<?php echo e(asset('content/images/about-us/img-safety.png')); ?>" />
                            <h5>Safety and well being</h5>
                        </div>
                        <div class="val-blk">
                            <img src="<?php echo e(asset('content/images/about-us/img-satisfaction.png')); ?>" />
                            <h5>Customer focus</h5>
                        </div>
                        <div class="val-blk">
                            <img src="<?php echo e(asset('content/images/about-us/img-collab.png')); ?>" />
                            <h5>Collaboration</h5>
                        </div>
                        <!-- f -->
                    </div>
                </div>
            </div>
        </section>
        <!--section 4-->
        <!--section 5-->
        <section>
            <?php echo $__env->make('frontend.energy_rate_block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </section>
        <!--section 5-->

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>