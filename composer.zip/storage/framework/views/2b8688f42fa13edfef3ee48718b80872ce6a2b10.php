<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1><?php echo e(trans('quickadmin::templates.templates-view_edit-edit')); ?></h1>

        <?php if($errors->any()): ?>
        	<div class="alert alert-danger">
        	    <ul>
                    <?php echo implode('', $errors->all('<li class="error">:message</li>')); ?>

                </ul>
        	</div>
        <?php endif; ?>
    </div>
</div>

<?php echo Form::model($contactus, array('class' => 'form-horizontal', 'id' => 'form-with-validation', 'method' => 'PATCH', 'route' => array(config('quickadmin.route').'.contactus.update', $contactus->id))); ?>


<div class="form-group">
    <?php echo Form::label('name', 'Name*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('name', old('name',$contactus->name), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('email', 'Email*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('email', old('email',$contactus->email), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('mobile', 'Mobile*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('mobile', old('mobile',$contactus->mobile), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('form_title', 'Form Title', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('form_title', old('form_title',$contactus->form_title), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('area_of_interest', 'Area of Interest', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('area_of_interest', old('area_of_interest',$contactus->area_of_interest), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('query', 'Query', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::textarea('query', old('query',$contactus->query), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('form_type', 'Form Type', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('form_type', old('form_type',$contactus->form_type), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('ip_address', 'IP Address', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('ip_address', old('ip_address',$contactus->ip_address), array('class'=>'form-control')); ?>

        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      <?php echo Form::submit(trans('quickadmin::templates.templates-view_edit-update'), array('class' => 'btn btn-primary')); ?>

      <?php echo link_to_route(config('quickadmin.route').'.contactus.index', trans('quickadmin::templates.templates-view_edit-cancel'), null, array('class' => 'btn btn-default')); ?>

    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>